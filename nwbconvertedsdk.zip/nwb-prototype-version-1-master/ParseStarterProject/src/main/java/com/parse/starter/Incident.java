package com.parse.starter;

public class Incident {

    private String type;
    private String when;
    private String address;


    public Incident(String type, String date, String address) {
        this.type = type;
        this.when = date;
        this.address = address;

    }


    public String getType() {
        return type;
    }

    public String getWhen() {
        return when;
    }

    public String getLocation() {
        return address;
    }

    }

