package com.parse.starter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.LogOutCallback;
import com.parse.Parse;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.util.ArrayList;
import java.util.List;

public class ViewEventsAdmin extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    ListView eventsListView;
    ArrayList<String> events = new ArrayList<>();
    ArrayList<String> names = new ArrayList<>();
    ArrayList<String> addresses = new ArrayList<>();
    ArrayAdapter arrayAdapter;

    String nameEvent;
    String addressEvent;
    String descriptionEvent;
    String timeEvent;
    String dateEvent;

    public void goBackEventsPage(View view) {
        Intent goBack = new Intent(getApplicationContext(), EventsAdmin.class);
        startActivity(goBack);
    }

    public void updateListView() {
        events.clear();
        ParseQuery<ParseObject> query = ParseQuery.getQuery("Events");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null) {
                    if (objects.size()>0) {
                        for (ParseObject object : objects) {
                            String name = object.getString("name");
                            String date = object.getString("date");
                            String time = object.getString("time");
                            String address = object.getString("address");
                            String submittedby = object.getString("submittedby");

                            names.add(name);
                            addresses.add(address);
                            events.add("Name: " + name + "\n" + "Address: " + address + "\n" + "When: " + date + "," + time + "\n" + "Created by: " + submittedby + "\n" + "\n");
                        }
                    }

                    else {
                        events.add("No events to show at this time.");
                    }

                    arrayAdapter.notifyDataSetChanged();
                }
            }
        });

    }

    // MENU STUFF

    public void showPopup(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.main_menu);
        popup.show();
    }

    public void goHome(View view) {
        Intent goHome = new Intent(getApplicationContext(), HomepageAdmin.class);
        goHome.putExtra("user", ParseUser.getCurrentUser().getString("name"));
        startActivity(goHome);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutButton) {
            ParseUser.logOut();
            Intent intentLogout = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intentLogout);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.logoutButton) {
            ParseUser.getCurrentUser().logOutInBackground(new LogOutCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Intent goToMain = new Intent(getApplicationContext(), MainActivity.class);
                        Toast.makeText(ViewEventsAdmin.this, "You are logged out", Toast.LENGTH_SHORT).show();
                        startActivity(goToMain);
                    }
                }
            });
        }

        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_events);
        getSupportActionBar().hide();

        eventsListView = (ListView) findViewById(R.id.listView);
        events.add("Test");
        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, events);
        eventsListView.setAdapter(arrayAdapter);

        events.clear();
        events.add("Loading all events...");

        updateListView();

        eventsListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


                ParseQuery<ParseObject> query2 = ParseQuery.getQuery("Events");
                query2.whereEqualTo("name",names.get(i));
                query2.whereEqualTo("address", addresses.get(i));
                query2.findInBackground(new FindCallback<ParseObject>() {
                    @Override
                    public void done(List<ParseObject> objects, ParseException e) {
                        if (e == null) {
                            if (objects.get(0) != null) {
                                nameEvent = objects.get(0).getString("name");
                                addressEvent = objects.get(0).getString("address");
                                timeEvent = objects.get(0).getString("time");
                                dateEvent = objects.get(0).getString("date");
                                descriptionEvent = objects.get(0).getString("description");

                                System.out.println("We are at object!");
                                System.out.println(nameEvent);

                                Intent intent = new Intent(getApplicationContext(), EditEventAdmin.class);
                                intent.putExtra("nameEvent", nameEvent);
                                intent.putExtra("addressEvent", addressEvent);
                                intent.putExtra("timeEvent", timeEvent);
                                intent.putExtra("dateEvent", dateEvent);
                                intent.putExtra("descriptionEvent", descriptionEvent);

                                startActivity(intent);
                            }

                            else {
                                System.out.println("object is null!");
                            }
                        }

                        else {
                            System.out.println("there is an error");
                        }
                    }
                });

            }
        });
    }
}
