package com.parse.starter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.util.List;

public class EditEventAdmin extends AppCompatActivity {

    EditText eventName;
    EditText eventAddress;
    EditText eventTime;
    EditText eventDate;
    EditText eventDescription;

    String name;
    String address;
    String time;
    String date;
    String description;

    public void goBack(View view) {
        Intent goBackIntent = new Intent(getApplicationContext(), ViewEventsAdmin.class);
        startActivity(goBackIntent);
    }

    public void updateEvent(final View view) {
        final ParseQuery<ParseObject> query = ParseQuery.getQuery("Events");
        query.whereEqualTo("name", name);
        query.whereEqualTo("address", address);
        query.whereEqualTo("time", time);
        query.whereEqualTo("date", date);
        query.whereEqualTo("description", description);


        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(final List<ParseObject> objects, ParseException e) {
                if (e == null) {

                    if (view.getId() == R.id.deleteButton && objects.get(0) != null) {

                            new AlertDialog.Builder(EditEventAdmin.this)
                                    .setIcon(android.R.drawable.ic_dialog_alert)
                                    .setTitle("Confirm Delete")
                                    .setMessage("Please note that deleting an event is permanent and will remove it from all user feeds.")
                                    .setPositiveButton("Delete Event", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {

                                            try {
                                                objects.get(0).delete();
                                                Toast.makeText(EditEventAdmin.this, "Event successfully deleted", Toast.LENGTH_SHORT).show();


                                            } catch (ParseException e1) {
                                                e1.printStackTrace();
                                                Toast.makeText(EditEventAdmin.this, "Event failed to delete. Try again later.", Toast.LENGTH_SHORT).show();
                                            }
                                        }
                                    })
                                    .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i) {
                                        }
                                    }).show();




                    }

                   else if (view.getId() == R.id.approveReportButton && objects.get(0) != null) {
                        objects.get(0).put("name", eventName.getText().toString());
                        objects.get(0).put("address", eventAddress.getText().toString());
                        objects.get(0).put("time", eventTime.getText().toString());
                        objects.get(0).put("date", eventDate.getText().toString());
                        objects.get(0).put("description", eventDescription.getText().toString());
                        objects.get(0).put("submittedby", ParseUser.getCurrentUser().getString("username"));

                        objects.get(0).saveInBackground(new SaveCallback() {
                            @Override
                            public void done(ParseException e) {

                                if (e == null) {
                                    Toast.makeText(EditEventAdmin.this, "Event successfully updated", Toast.LENGTH_SHORT).show();
                                }

                                else {
                                    Toast.makeText(EditEventAdmin.this, "Event failed to update. Please try again later", Toast.LENGTH_SHORT).show();
                                }

                            }
                        });
                    }
                }

            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_event_admin);

        getSupportActionBar().hide();

        eventName = (EditText) findViewById(R.id.typeEditText);
        eventAddress = (EditText) findViewById(R.id.addressEditText);
        eventTime = (EditText) findViewById(R.id.timeEditText);
        eventDate = (EditText) findViewById(R.id.dateEditText);
        eventDescription = (EditText) findViewById(R.id.descriptionEditText);


        Intent intent = getIntent();
        name = intent.getStringExtra("nameEvent");
        address = intent.getStringExtra("addressEvent");
        time = intent.getStringExtra("timeEvent");
        date = intent.getStringExtra("dateEvent");
        description = intent.getStringExtra("descriptionEvent");

        System.out.println(name);
        System.out.println(address);

        eventName.setText(name);
        eventAddress.setText(address);
        eventTime.setText(time);
        eventDate.setText(date);
        eventDescription.setText(description);

    }
}
