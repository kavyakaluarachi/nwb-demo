package com.parse.starter;

import android.content.Context;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class EventsListAdapter extends ArrayAdapter<Event> {

    private Context mContext;
    int mResource;

    public EventsListAdapter(@NonNull Context context, int resource, @NonNull List<Event> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String name = getItem(position).getName();
        String date = getItem(position).getDate();
        String address = getItem(position).getAddress();
        String time = getItem(position).getTime();

        // create new event object with info
        Event event = new Event(name, date, address, time);
        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView nameTV = (TextView) convertView.findViewById(R.id.userInfo);
        TextView dateTV = (TextView) convertView.findViewById(R.id.incidentDateTV);
        TextView addressTV = (TextView) convertView.findViewById(R.id.messageInfo);

        nameTV.setText(name);
        nameTV.setTypeface(null, Typeface.BOLD);
        dateTV.setText(date + "\n" + time);
        addressTV.setText(address);

        return convertView;
    }


}
