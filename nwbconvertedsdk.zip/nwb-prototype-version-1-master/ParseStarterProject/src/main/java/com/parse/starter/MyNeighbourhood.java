package com.parse.starter;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.StyleSpan;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.io.IOException;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import static java.lang.Math.abs;

public class MyNeighbourhood extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    ListView incidentsList;

    ArrayList<Incident> incidents = new ArrayList<>();

    TextView neighbourhood;
    TextView local;
    double homeLat;
    double homeLong;
    Incident incident = null;
    Location home = new Location(LocationManager.GPS_PROVIDER);

    public void buttonClick(View view) {
        if (view.getId() == R.id.neighbourhoodIncidents) {
            updateList("local");
            neighbourhood.setTextColor(Color.parseColor("#FFFFEB3B"));
            local.setTextColor(Color.parseColor("#FDFDFE"));

        }

        if (view.getId() == R.id.bramptonIncidents) {
            updateList("brampton");
            local.setTextColor(Color.parseColor("#FFFFEB3B"));
            neighbourhood.setTextColor(Color.parseColor("#FDFDFE"));
        }
    }

    public void updateList(final String key) {
        incidents.clear();
        ParseQuery<ParseObject> query = ParseQuery.getQuery("IncidentReports");
        System.out.println(key);
        query.whereEqualTo("status", "approved");

        final Geocoder geocoder = new Geocoder(this);
        try {
            // gets the user's address
            List<Address> list = geocoder.getFromLocationName(ParseUser.getCurrentUser().getString("address"), 1);
            Address address = list.get(0);
             homeLat = address.getLatitude();
             homeLong = address.getLongitude();

             home.setLatitude(homeLat);
             home.setLongitude(homeLong);

            System.out.println(Double.toString(homeLat) + "," + Double.toString(homeLong));

        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Sorry, error found!");
        }

        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null) {
                    if (objects.size()>0) {

                        if (key == "local") {
                            // we only want to add distances which are less than <= 7000 away

                            for (ParseObject object : objects) {
                                try {

                                    // check the address of the incident, and see distance
                                    List<Address> incidentAdd = geocoder.getFromLocationName(object.getString("address"), 1);
                                    Address add = incidentAdd.get(0);
                                    double lat = add.getLatitude();
                                    double lng = add.getLongitude();

                                    Location incidentLoc = new Location(LocationManager.GPS_PROVIDER);
                                    incidentLoc.setLatitude(lat);
                                    incidentLoc.setLongitude(lng);

                                    if (home.distanceTo(incidentLoc) <= 7000) {
                                        System.out.println("within neighbourhood");

                                        String type = object.getString("incident");
                                        String date = object.getString("date");
                                        String time = object.getString("time");
                                        String address = object.getString("address");

                                        String when = date + "\n" + time;

                                        incident = new Incident(type,when, address);
                                        incidents.add(incident);
//                                        incidents.add("\n" + "Incident:" + object.getString("incident") + "\n" +
//                                                "Location: " + object.getString("address") + "\n" +
//                                                "Date: " + object.getString("date") + "\n");
                                    }

                                } catch (IOException e1) {
                                    e1.printStackTrace();
                                }
                            }

                        }

                        // else, if key is brampton we want to load all incidents

                        else if (key == "brampton") {
                            for (ParseObject object : objects) {

                                String type = object.getString("incident");
                                String date = object.getString("date");
                                String time = object.getString("time");
                                String address = object.getString("address");

                                String when = date + "\n" + time;

                                incident = new Incident(type,when, address);
                                incidents.add(incident);


//                                incidents.add("\n" + "Incident:" + object.getString("incident") + "\n" +
//                                        "Location: " + object.getString("address") + "\n" +
//                                        "Date: " + object.getString("date") + "\n");
                            }
                        }

                        IncidentListAdapter adapter = new IncidentListAdapter(MyNeighbourhood.this, R.layout.custom_layout2, incidents);
                        incidentsList.setAdapter(adapter);

//                        arrayAdapter.notifyDataSetChanged();
                    }


                }
            }
        });

    }



    // MENU STUFF
    public void showPopup(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.main_menu);
        popup.show();
    }

    public void goHome(View view) {
        Intent goHome = new Intent(getApplicationContext(), Homepage.class);
        goHome.putExtra("user", ParseUser.getCurrentUser().getString("name"));
        startActivity(goHome);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutButton) {
            ParseUser.logOut();
            Intent intentLogout = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intentLogout);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.logoutButton) {
            ParseUser.getCurrentUser().logOutInBackground(new LogOutCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Intent goToMain = new Intent(getApplicationContext(), MainActivity.class);
                        Toast.makeText(MyNeighbourhood.this, "You are logged out", Toast.LENGTH_SHORT).show();
                        startActivity(goToMain);
                    }
                }
            });
        }

        return true;
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_neighbourhood);
        getSupportActionBar().hide();

        neighbourhood = (TextView) findViewById(R.id.neighbourhoodIncidents);
        neighbourhood.setTypeface(null, Typeface.BOLD);
        local = (TextView) findViewById(R.id.bramptonIncidents);
        local.setTypeface(null, Typeface.BOLD);

        incidentsList = (ListView) findViewById(R.id.listView);
//        incidents.add("Test");
//        arrayAdapter = new ArrayAdapter(this, android.R.layout.simple_list_item_1, incidents);
//        incidentsList.setAdapter(arrayAdapter);
//
//        incidents.clear();
//        incidents.add("Loading all incidents...");
//
        updateList("local");



    }
}
