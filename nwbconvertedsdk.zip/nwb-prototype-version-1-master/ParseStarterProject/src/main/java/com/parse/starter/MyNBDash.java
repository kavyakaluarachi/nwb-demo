package com.parse.starter;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseUser;

public class MyNBDash extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    TextView descriptionTV;
    TextView viewIncidentsTV;
    TextView viewEventsTV;



    public void goToNewPage(View view) {
        if (view.getId() == R.id.viewEventsTV) {
            System.out.println("going to events");
            Intent intent2 = new Intent(getApplicationContext(), ViewEventsUser.class);
            startActivity(intent2);
        }

        else if (view.getId() == R.id.viewIncidentsTV) {
            Intent intent = new Intent(getApplicationContext(), MyNeighbourhood.class);
            startActivity(intent);

        }
    }


    // MENU STUFF
    public void showPopup(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.main_menu);
        popup.show();
    }

    public void goHome(View view) {
        Intent goHome = new Intent(getApplicationContext(), Homepage.class);
        goHome.putExtra("user", ParseUser.getCurrentUser().getString("name"));
        startActivity(goHome);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutButton) {
            ParseUser.logOut();
            Intent intentLogout = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intentLogout);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.logoutButton) {
            ParseUser.getCurrentUser().logOutInBackground(new LogOutCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Intent goToMain = new Intent(getApplicationContext(), MainActivity.class);
                        Toast.makeText(MyNBDash.this, "You are logged out", Toast.LENGTH_SHORT).show();
                        startActivity(goToMain);
                    }
                }
            });
        }

        return true;
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_my_nbdash);
        getSupportActionBar().hide();

        descriptionTV = (TextView) findViewById(R.id.descriptionTV);
        descriptionTV.setText("Want to know what's happening in your area?" + "\n"  +
                "Click below to find out which events are happening both in the city and near you," +
                " alongside any crime reports in your area.");

        viewEventsTV = (TextView) findViewById(R.id.viewEventsTV);
        viewIncidentsTV = (TextView) findViewById(R.id.viewIncidentsTV);
    }
}
