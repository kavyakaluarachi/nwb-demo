package com.parse.starter;

import android.app.DownloadManager;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationManager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import com.parse.FindCallback;
import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseQuery;
import com.parse.ParseUser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class ViewEventsUser extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener {

    ListView eventsListView;
    ArrayList<Event> eventList = new ArrayList<Event>();
    Event event = null;
    Location home = new Location(LocationManager.GPS_PROVIDER);
    TextView nearMeButton;
    TextView bramptonButton;
    TextView noEvents;

    public void buttonClickEvent(View view) {

        if (view.getId() == R.id.allEvents) {
            update("brampton");
            bramptonButton.setTextColor(Color.parseColor("#FDFDFE"));
            nearMeButton.setTextColor(Color.parseColor("#2374D2"));
        }

        else if (view.getId() == R.id.eventsNearMe) {
            update("local");
            nearMeButton.setTextColor(Color.parseColor("#FDFDFE"));
            bramptonButton.setTextColor(Color.parseColor("#2374D2"));
        }
    }


    public void update(final String key) {

        eventList.clear();

        final Geocoder geocoder = new Geocoder(this);
        try {
            List<Address> list = geocoder.getFromLocationName(ParseUser.getCurrentUser().getString("address"), 1);
            Address address = list.get(0);
            Double homeLat = address.getLatitude();
            Double homeLong = address.getLongitude();
            home.setLatitude(homeLat);
            home.setLongitude(homeLong);

        } catch (IOException e) {
            e.printStackTrace();
            Log.i("Location error:", "error in geolocator");
        }

        ParseQuery<ParseObject> query = ParseQuery.getQuery("Events");
        query.findInBackground(new FindCallback<ParseObject>() {
            @Override
            public void done(List<ParseObject> objects, ParseException e) {
                if (e == null) {
                    if (objects.size()>0) {

                        noEvents.setVisibility(View.INVISIBLE);

                        System.out.println("objects size > 0");
                        for (ParseObject object: objects) {

                            String address = object.getString("address");

                            // get location:
                            try {
                                List<Address> eventAdd  = geocoder.getFromLocationName(object.getString("address"), 1);
                                Address add = eventAdd.get(0);
                                double lat = add.getLatitude();
                                double lng = add.getLongitude();

                                Location eventLocation = new Location(LocationManager.GPS_PROVIDER);
                                eventLocation.setLatitude(lat);
                                eventLocation.setLongitude(lng);

                                if (key == "local") {
                                    if (home.distanceTo(eventLocation) <= 7000) {

                                        String name = object.getString("name");
                                        String date = object.getString("date");
                                        String time = object.getString("time");


                                        event = new Event(name, date, address, time);
                                        eventList.add(event);
                                        System.out.println(eventList.size());

                                    }
                                }

                                else if (key == "brampton") {
                                    String name = object.getString("name");
                                    String date = object.getString("date");
                                    String time = object.getString("time");


                                    event = new Event(name, date, address, time);
                                    eventList.add(event);
                                    System.out.println(eventList.size());
                                }


                            } catch (IOException e1) {
                                e1.printStackTrace();
                                Log.i("Location error:", "error in geolocator for event");

                            }



                        }

                        EventsListAdapter adapter = new EventsListAdapter(ViewEventsUser.this, R.layout.custom_layout, eventList);
                        eventsListView.setAdapter(adapter);

                    }

                    else {
                        System.out.println("objects empty");
                    }
                }
            }
        });


    }


    // MENU STUFF

    public void showPopup(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.main_menu);
        popup.show();
    }

    public void goHome(View view) {
        Intent goHome = new Intent(getApplicationContext(), Homepage.class);
        goHome.putExtra("user", ParseUser.getCurrentUser().getString("name"));
        startActivity(goHome);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutButton) {
            ParseUser.logOut();
            Intent intentLogout = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intentLogout);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.logoutButton) {
            ParseUser.getCurrentUser().logOutInBackground(new LogOutCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Intent goToMain = new Intent(getApplicationContext(), MainActivity.class);
                        Toast.makeText(ViewEventsUser.this, "You are logged out", Toast.LENGTH_SHORT).show();
                        startActivity(goToMain);
                    }
                }
            });
        }

        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_events_user);

        eventsListView = (ListView) findViewById(R.id.listViewEvents);
        noEvents = (TextView) findViewById(R.id.noEventsText);

        nearMeButton = (TextView) findViewById(R.id.eventsNearMe);
        nearMeButton.setTypeface(null, Typeface.BOLD);
        bramptonButton = (TextView) findViewById(R.id.allEvents);
        bramptonButton.setTypeface(null, Typeface.BOLD);


        getSupportActionBar().hide();

        update("local");
//
//        Event cats = new Event("Play with cats", "January 27", "88 river rock cres");
//        Event dogs = new Event("Play with dogs", "January 27", "88 river rock cres");
//        Event sloths = new Event("Play with sloths", "January 27", "88 river rock cres");
//
//        eventList.add(cats);
//        eventList.add(dogs);
//        eventList.add(sloths);
//
//        System.out.println(eventList.size());



    }


}
