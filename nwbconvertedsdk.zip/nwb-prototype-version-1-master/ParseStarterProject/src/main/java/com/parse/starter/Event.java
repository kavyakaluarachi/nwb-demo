package com.parse.starter;

public class Event {

    private String name;
    private String date;
    private String address;
    private String time;

    public Event(String name, String date, String address, String time) {
        this.name = name;
        this.date = date;
        this.address = address;
        this.time = time;
    }

    public String getName() {
        return name;
    }

    public String getDate() {
        return date;
    }

    public String getAddress() {
        return address;
    }

    public String getTime() { return time;
    }

}
