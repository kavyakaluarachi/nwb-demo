package com.parse.starter;

import android.content.Context;
import android.graphics.Typeface;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class IncidentListAdapter extends ArrayAdapter<Incident> {

    private Context mContext;
    int mResource;

    public IncidentListAdapter(@NonNull Context context, int resource, @NonNull List<Incident> objects) {
        super(context, resource, objects);
        mContext = context;
        mResource = resource;
    }


    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        String type = getItem(position).getType();
        String when = getItem(position).getWhen();
        String location = getItem(position).getLocation();

        // create new event object with info
        Incident incident = new Incident(type, when, location);
        LayoutInflater inflater = LayoutInflater.from(mContext);
        convertView = inflater.inflate(mResource, parent, false);

        TextView incidentType = (TextView) convertView.findViewById(R.id.userInfo);
        TextView incidentDate = (TextView) convertView.findViewById(R.id.incidentDateTV);
        TextView incidentAddress = (TextView) convertView.findViewById(R.id.messageInfo);

        incidentType.setText(type);
        incidentType.setTypeface(null, Typeface.BOLD);
        incidentDate.setText(when);
        incidentAddress.setText(location);

        return convertView;
    }
}
