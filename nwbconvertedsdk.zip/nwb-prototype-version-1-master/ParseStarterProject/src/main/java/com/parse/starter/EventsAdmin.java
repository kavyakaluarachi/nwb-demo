package com.parse.starter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class EventsAdmin extends AppCompatActivity {

    EditText eventNameEditText;
    EditText eventTimeEditText;
    EditText eventAddressEditText;
    EditText eventDateEditText;
    EditText eventDescriptionEditText;
    String datePosted;

    public void goToView(View view) {
        Intent viewIntent = new Intent(getApplicationContext(), ViewEventsAdmin.class);
        startActivity(viewIntent);
    }

    public void onButtonClick(View view) {
        String name = eventNameEditText.getText().toString();
        String address = eventAddressEditText.getText().toString();
        String date = eventDateEditText.getText().toString();
        String time = eventTimeEditText.getText().toString();
        String description = eventDescriptionEditText.getText().toString();

        if (name.matches("") || address.matches("") || date.matches("") || time.matches("") || description.matches("")) {
            Toast.makeText(EventsAdmin.this, "Please ensure all fields are complete before submitting", Toast.LENGTH_SHORT).show();
        }

        else {

            ParseObject events = new ParseObject("Events");
            events.put("name", name);
            events.put("address", address);
            events.put("description", description);
            events.put("date", date);
            events.put("time", time);
            events.put("submittedby", ParseUser.getCurrentUser().getString("username"));
            events.put("dateposted", datePosted);

            events.saveInBackground(new SaveCallback() {
                @Override
                public void done(ParseException e) {

                    if (e == null) {
                        Log.i("Save Event", "Successful");
                        Toast.makeText(EventsAdmin.this, "Successfully created event.", Toast.LENGTH_SHORT).show();

                        new AlertDialog.Builder(EventsAdmin.this)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .setTitle("Event Created!")
                                .setMessage("Event has been successfuly created. The event is now viewable to all users.")
                                .setPositiveButton("Back to home", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {

                                        Intent intent = new Intent(getApplicationContext(), HomepageAdmin.class);
                                        intent.putExtra("user", ParseUser.getCurrentUser().getString("name"));
                                        startActivity(intent);

                                    }
                                })
                                .setNegativeButton("Create Another Event", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                }).show();

                    } else {
                        Log.i("Save Event", "Failed");
                        Toast.makeText(EventsAdmin.this, "Unable to create event. Please try again later.", Toast.LENGTH_SHORT).show();
                    }

                }
            });

        }

    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_events_admin);

        getSupportActionBar().hide();

        eventNameEditText = (EditText) findViewById(R.id.typeEditText);
        eventTimeEditText = (EditText) findViewById(R.id.timeEditText);
        eventAddressEditText = (EditText) findViewById(R.id.addressEditText);
        eventDateEditText = (EditText) findViewById(R.id.dateEditText);
        eventDescriptionEditText = (EditText) findViewById(R.id.descriptionEditText);



        // get date
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        datePosted = df.format(date);



    }
}
