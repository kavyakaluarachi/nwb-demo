package com.parse.starter;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.PopupMenu;
import android.widget.Spinner;
import android.widget.Toast;

import com.parse.LogOutCallback;
import com.parse.ParseException;
import com.parse.ParseObject;
import com.parse.ParseUser;
import com.parse.SaveCallback;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class FileReport extends AppCompatActivity implements View.OnClickListener, PopupMenu.OnMenuItemClickListener {

    Spinner incidentTypeSpinner;
    ParseUser user;
    EditText addressIncident;
    EditText descriptionIncident;
    EditText referenceIncident;
    EditText timeIncident;
    String incidentType;
    EditText dateIncident;
    String currentDate;



    // submitting the report + saving it onto parse
    public void submitReport(View view) {

        if (addressIncident.getText().toString().matches("") ||
                descriptionIncident.getText().toString().matches("")||
                referenceIncident.getText().toString().matches("") ||
                timeIncident.getText().toString().matches("")){

            Toast.makeText(FileReport.this, "Please ensure all fields are complete before submitting", Toast.LENGTH_SHORT).show();
        }

        else {
            String address = addressIncident.getText().toString();
            String description = descriptionIncident.getText().toString();
            String reference = referenceIncident.getText().toString();
            String time = timeIncident.getText().toString();
            String date = dateIncident.getText().toString();

            ParseObject incidentReports = new ParseObject("IncidentReports");
            incidentReports.put("address", address);
            incidentReports.put("description", description);
            incidentReports.put("date", date);
            incidentReports.put("reference", reference);
            incidentReports.put("time", time);
            incidentReports.put("username", user.getString("username"));
            incidentReports.put("incident", incidentType);
            incidentReports.put("datesubmitted", currentDate);
            incidentReports.put("status", "pending");
            incidentReports.saveInBackground(new SaveCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Log.i("Save Report", "Successful");
                        Toast.makeText(FileReport.this, "Successfully submitted incident report.", Toast.LENGTH_SHORT).show();

                        new AlertDialog.Builder(FileReport.this)
                                .setIcon(android.R.drawable.ic_dialog_alert)
                                .setTitle("Report Submitted")
                                .setMessage("Thank you for reporting this incident. We will review it as soon as we can and may contact you for additional information.")
                                .setPositiveButton("Close", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                        backToHomepage();
                                    }
                                })
                                .setNegativeButton("Submit Another Report", new DialogInterface.OnClickListener() {
                                    @Override
                                    public void onClick(DialogInterface dialogInterface, int i) {
                                    }
                                }).show();

                    }
                    else {
                        Log.i("Save Report", "Failed");
                        Toast.makeText(FileReport.this, "Unable to report incident. Please try again later.", Toast.LENGTH_SHORT).show();
                    }
                }
            });

        }

    }



    // MENU STUFF
    public void showPopup(View view) {
        PopupMenu popup = new PopupMenu(this, view);
        popup.setOnMenuItemClickListener(this);
        popup.inflate(R.menu.main_menu);
        popup.show();
    }

    public void goHome(View view) {
        Intent goHome = new Intent(getApplicationContext(), Homepage.class);
        goHome.putExtra("user", ParseUser.getCurrentUser().getString("name"));
        startActivity(goHome);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater menuInflater = getMenuInflater();
        menuInflater.inflate(R.menu.main_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == R.id.logoutButton) {
            ParseUser.logOut();
            Intent intentLogout = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intentLogout);
        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        if (menuItem.getItemId() == R.id.logoutButton) {
            ParseUser.getCurrentUser().logOutInBackground(new LogOutCallback() {
                @Override
                public void done(ParseException e) {
                    if (e == null) {
                        Intent goToMain = new Intent(getApplicationContext(), MainActivity.class);
                        Toast.makeText(FileReport.this, "You are logged out", Toast.LENGTH_SHORT).show();
                        startActivity(goToMain);
                    }
                }
            });
        }

        return true;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_file_report);
        getSupportActionBar().hide();

        // get date
        DateFormat df = new SimpleDateFormat("yyyy/MM/dd");
        Date date = new Date();
        currentDate = df.format(date);


        // initialize user
        user = ParseUser.getCurrentUser();

        // initialize widgets
        addressIncident = (EditText) findViewById(R.id.usernameEditText);
        descriptionIncident = (EditText) findViewById(R.id.descriptionIncident);
        referenceIncident = (EditText) findViewById(R.id.referenceIncident);
        timeIncident = (EditText) findViewById(R.id.timeIncident);
        dateIncident = (EditText) findViewById(R.id.dateIncident);
        Button submitButton = (Button) findViewById(R.id.declineReportButton);

        // set up spinner/drop down menu
        incidentTypeSpinner = (Spinner) findViewById(R.id.incidentTypeSpinner);
        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(FileReport.this,
                android.R.layout.simple_list_item_1, getResources().getStringArray(R.array.incidents));
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        incidentTypeSpinner.setAdapter(arrayAdapter);

        incidentTypeSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                incidentType = adapterView.getItemAtPosition(i).toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {
                incidentType="";
            }
        });


        // create alert

        new AlertDialog.Builder(this)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .setTitle("Important Information")
                .setMessage("Reporting an incident is to be used for non-emergency uses only. If your incident requires emergency attention, " +
                        "please call 9-1-1 first. For municipal services, please call 3-1-1 first.")
                .setPositiveButton("Continue", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // when continue is clicked
                        Toast.makeText(FileReport.this, "Continue to report incident", Toast.LENGTH_SHORT).show();

                    }
                })
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // cancel is selected, return to homepage
                      backToHomepage();
                    }
                }).show();

    }

    public void backToHomepage() {
        Intent homeIntent = new Intent(getApplicationContext(), Homepage.class);
        homeIntent.putExtra("user", user.getString("name"));
        startActivity(homeIntent);
    }

    @Override
    public void onClick(View view) {
        if (view.getId() == R.id.constraintLayout) {
            InputMethodManager inputMethodManager = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
            inputMethodManager.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);
        }
    }
}
